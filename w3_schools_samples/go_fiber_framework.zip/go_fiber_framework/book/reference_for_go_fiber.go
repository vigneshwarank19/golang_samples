/*1.fiber is a framework for golang .
2.fiber use instead of node js.
3."u"-every project need main package it only one in one project.
4.every function name need to start "capital letter".
5.every single project need to install "mod and sum " folders.
6.every project have only one main package.
7.after that main package where we name every package in separate name
8.what present in mod- module name we only use that name and directory folder */