package main

import (
	"fmt"

	"github.com/gofiber/fiber"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
	"github.com/vigneshwaran/go_fiber_framework/book"
	"github.com/vigneshwaran/go_fiber_framework/database"
)

// ctx means "fiber context"
func Helloworld(c *fiber.Ctx) {
	c.Send("HELLO PETER")
}
func Setuproutes(app *fiber.App) {
	app.Get("/", Helloworld)
	app.Get("/api/v1/book", book.GetBooks)
	app.Get("/api/v1/book/:id", book.GetBook)
	app.Post("/api/v1/book", book.NewBook)
	app.Delete("/api/v1/book/:id", book.DeleteBook)
}
func initDatabase() {
	var err error
	database.DBConn, err = gorm.Open("sqlite3", "books.db")
	if err != nil {
		panic("failed to connect database")
	}
	fmt.Println("connection opened to database")
	database.DBConn.AutoMigrate(&book.Book{})
	fmt.Println("Database Migrated")
}
func main() {
	app := fiber.New()
	initDatabase()
	defer database.DBConn.Close()
	Setuproutes(app)
	fmt.Println("Before start server..")
	app.Listen(4000)
	fmt.Println("Server ends")

}
